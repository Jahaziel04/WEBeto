<!DOCTYPE html>
<html xml:lang="es-es" lang="es-es" >

	<head>
		<link rel="stylesheet" href="css/main.css" type="text/css" />
		<link rel="stylesheet" href="css/menu.css" type="text/css" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<title>Abogado en chiapas</title>
		
		<!--[if IE]>
  			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
	</head>

<body>

	<header>
		
		<div class="header_title" >
			
			<div class="l_header">
				<img class="logo_header" src="img/logo_m.png"  alt="Coello's & Asociados" >
			</div>
			
			<div class="r_header">
				<div class="titulo_s" >Despacho Jurídico</div>
				<div class="titulo_m" >Coello’S & Asociados</div>
				<div class="titulo_s" >Investigaciones Privadas y</div>
				<div class="titulo_s" >Servicios Periciales</div>
			</div>
			
		<div>	
			
        <ul class="menu">
            <li><a class="menu_item" href="#">Inicio</a></li>
            <li class="anidado" >
                <a class="menu_item" href="#">Blog <span class="arrow">&#9660;</span></a> 
                <ul class="submenu">
                    <li><a class="submenu_item" href="#">Acerca del reparto de utilidades</a></li>
                    <li><a class="submenu_item" href="#">Hostigar deudores: delito en DF</a></li>
                    <li><a class="submenu_item" href="#">Divorcio express en aumento</a></li>
                    <li><a class="submenu_item" href="#">Sobre la pensión de alimentos</a></li>
                </ul>
            </li>
            <li class="anidado">
                <a class="menu_item" href="#">Acerca de ... <span class="arrow">&#9660;</span></a> 
                <ul class="submenu">
                    <li><a class="submenu_item" href="#">Síntesis curricular</a></li>
                    <li><a class="submenu_item" href="#">Actividad académica</a></li>
                    <li><a class="submenu_item" href="#">Cursos y diplomados</a></li>
                    <li><a class="submenu_item" href="#">Experiencia laboral</a></li>
                    <li><a class="submenu_item" href="#">Publicaciones</a></li>
                </ul>
            </li>
            <li><a class="menu_item" href="#">Menú de servicios</a></li>
        </ul>
	</header>
	
	<article>
		
		<h2 class="titulo_principal">Un abogado en chiapas para todas sus necesidades legales</h2>
			
	
		<p>
			Nos especializamos en defensa penal ante el ministerio público y juzgados, Defensa legal contra bancos, Desalojos judiciales por incumplimiento de rentas, Propiedades embargadas, Custodia de menores e Investigaciones Privadas, Indemnización por Despido Injustificado, Divorcio Express, Gestión de Cobranza Difícil, Peritajes.
		</p>

		<iframe src="https://www.youtube.com/embed/jYhFJ1VWiAo" width="560" height="315" frameborder="0" allowfullscreen=""></iframe>
	
	
		<ul class="lista_check">
			<li style="text-align: left;"><em> Despido Injustificado (Asesoría Obrero-Patronal).</em></li>
			<li style="text-align: left;"><em>Divorcio Express y Pensión de Alimentos.</em></li>
			<li style="text-align: left;"><em> Gestión de Cobranza y Recuperación de Cartera Vencida.</em></li>
		</ul>

		<h2 class="titulo_h2">Misión</h2>

		<p>
			El Despacho Jurídico Coello’s & Asociados es una asociación de profesionales que tiene como misión principal, solucionar los conflictos y necesidades legales de nuestros clientes, 
			planteándoles las mejores alternativas para alcanzar el éxito deseado en las acciones efectuadas, compartiéndoles nuestra filosofía y valores, con el objeto de asegurar una relación armoniosa,  
			honesta, responsable y con alto sentido de profesionalismo, garantizándoles atención personalizada así como el apoyo total de nuestros asociados, peritos y demás auxiliares,  
			obteniendo de esta manera una adecuada competitividad con el propósito de lograr nuestra permanencia, desarrollo y crecimiento en el ámbito de la Seguridad Pública, Procuración y 
			Administración de Justicia.
		</p>
	
		<h2 class="titulo_h2">Visión</h2>	

		<p>
			El Despacho Jurídico Coello’s & Asociados tiene como visión principal, servir con valores éticos y lealtad, cada vez a un mayor número de clientes, comunidades, 
			grupos sociales, personas físicas y/o morales, creando una <a class="link" title="Bolsa de Trabajo" href="http://abogadochiapas.com/bolsa-de-trabajo/"> exitosa red de asociados</a> 
			que ofrezcan la mejor asesoría y representación legal como <a class="link" title="Menú de Servicios" href="http://abogadochiapas.com/servicios/">abogados en Chiapas</a>. 
			Así como el mejor ambiente laboral para nuestros colaboradores, consecuencia de una constante, continua y permanente innovación.
		</p>	
	</article>	

	<footer>
		<div class="contador_visitas">		
		<img src="img/logo_s.png" alt="Coello's & Asociados" >
		<br>
		Coello's & Asociados
		<br>
		<a class="link" href="http://www.contadorvisitasgratis.com" target="_Blank" title="contador de visitas">contador de visitas</a><br>
		<script type="text/javascript" src="http://counter6.allfreecounter.com/private/countertab.js?c=213b0a4e5f1617e2e32b5f26800a3965"></script>
		</div>
		
		<div class="footer_text_margin"><strong class="custom">"Para que lo legal sea justo"</strong></div>
		<div class="footer_text">Copyright © 2015 Abogado en Chiapas - Coello's & Asociados.</div>		 
		<div class="footer_text">Todos los derechos Reservados.</div>		 
		<div class="footer_text_margin">Teléfonos: <strong class="custom">961.25.4.34.74</strong> y/o <strong class="custom">961.24.54.650</strong></div>
		<div class="footer_text">e-mail: coellosyasociados@hotmail.com</div>
		 
	</footer>

</body>


</html> 
